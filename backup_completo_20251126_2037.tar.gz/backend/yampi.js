const axios = require('axios');
const db = require('./database');

const YAMPI_BASE_URL = 'https://api.dooki.com.br/v2';

// Função para obter configuração
function getConfig(chave) {
  const config = db.prepare('SELECT valor FROM configuracoes WHERE chave = ?').get(chave);
  return config ? config.valor : null;
}

// Função para criar cliente Axios com headers Yampi
function getYampiClient() {
  const alias = getConfig('yampi_alias');
  const token = getConfig('yampi_token');
  const secret = getConfig('yampi_secret');

  if (!alias || !token || !secret) {
    throw new Error('Configurações da Yampi incompletas');
  }

  return axios.create({
    baseURL: `${YAMPI_BASE_URL}/${alias}`,
    headers: {
      'Content-Type': 'application/json',
      'User-Token': token,
      'User-Secret-Key': secret
    },
    timeout: 30000
  });
}

// ============= PEDIDOS =============

/**
 * Buscar pedidos da Yampi
 * @param {Object} params - Parâmetros de filtro (page, limit, status, etc)
 * @returns {Promise<Object>} - Lista de pedidos
 */
async function buscarPedidos(params = {}) {
  try {
    const client = getYampiClient();
    
    // Parâmetros padrão
    const queryParams = {
      page: params.page || 1,
      limit: params.limit || 50,
      include: 'items.sku_variant.sku.product,customer',
      ...params
    };

    const response = await client.get('/orders', { params: queryParams });
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar pedidos Yampi:', error.message);
    if (error.response) {
      console.error('Resposta da API:', error.response.data);
    }
    throw error;
  }
}

/**
 * Buscar pedido específico por ID
 * @param {number} orderId - ID do pedido na Yampi
 * @returns {Promise<Object>} - Dados do pedido
 */
async function buscarPedido(orderId) {
  try {
    const client = getYampiClient();
    const response = await client.get(`/orders/${orderId}`, {
      params: { include: 'items.sku_variant.sku.product,customer' }
    });
    return response.data;
  } catch (error) {
    console.error(`Erro ao buscar pedido ${orderId}:`, error.message);
    throw error;
  }
}

/**
 * Sincronizar pedidos da Yampi para o banco local
 * @param {Object} options - Opções de sincronização
 * @returns {Promise<Object>} - Resultado da sincronização
 */
async function sincronizarPedidos(options = {}) {
  try {
    console.log('🔄 Iniciando sincronização de pedidos Yampi...');
    
    const params = {
      page: options.page || 1,
      limit: options.limit || 50,
      'q[payment.status][in]': 'paid,partially_refunded', // Apenas pedidos pagos
      ...options.filters
    };

    const resultado = await buscarPedidos(params);
    const pedidos = resultado.data || [];
    
    let novos = 0;
    let atualizados = 0;
    let erros = 0;

    for (const pedido of pedidos) {
      try {
        await salvarPedido(pedido);
        
        // Verificar se já existe
        const existe = db.prepare('SELECT id FROM pedidos_yampi WHERE yampi_order_id = ?')
          .get(pedido.id);
        
        if (existe) {
          atualizados++;
        } else {
          novos++;
        }
      } catch (error) {
        console.error(`Erro ao salvar pedido ${pedido.number}:`, error.message);
        erros++;
      }
    }

    const total = novos + atualizados;
    console.log(`✅ Sincronização concluída: ${novos} novos, ${atualizados} atualizados, ${erros} erros`);

    return {
      sucesso: true,
      total,
      novos,
      atualizados,
      erros,
      totalPaginas: resultado.meta?.pagination?.total_pages || 1,
      paginaAtual: resultado.meta?.pagination?.current_page || 1
    };

  } catch (error) {
    console.error('❌ Erro na sincronização:', error.message);
    return {
      sucesso: false,
      erro: error.message
    };
  }
}

/**
 * Salvar pedido no banco local
 * @param {Object} pedido - Dados do pedido da Yampi
 */
async function salvarPedido(pedido) {
  // Verificar se já existe
  const existe = db.prepare('SELECT id FROM pedidos_yampi WHERE yampi_order_id = ?')
    .get(pedido.id);

  const dadosPedido = {
    yampi_order_id: pedido.id,
    numero_pedido: pedido.number,
    status_financeiro: pedido.payment?.status || 'pending',
    status_entrega: pedido.shipment?.status || 'pending',
    cliente_nome: pedido.customer?.name || '',
    cliente_email: pedido.customer?.email || '',
    valor_total: parseFloat(pedido.value_total || 0),
    data_pedido: pedido.created_at?.date || new Date().toISOString(),
    json_completo: JSON.stringify(pedido)
  };

  if (existe) {
    // Atualizar
    db.prepare(`
      UPDATE pedidos_yampi SET
        status_financeiro = ?,
        status_entrega = ?,
        valor_total = ?,
        json_completo = ?,
        data_sincronizacao = CURRENT_TIMESTAMP
      WHERE yampi_order_id = ?
    `).run(
      dadosPedido.status_financeiro,
      dadosPedido.status_entrega,
      dadosPedido.valor_total,
      dadosPedido.json_completo,
      dadosPedido.yampi_order_id
    );
  } else {
    // Inserir
    const result = db.prepare(`
      INSERT INTO pedidos_yampi (
        yampi_order_id, numero_pedido, status_financeiro, status_entrega,
        cliente_nome, cliente_email, valor_total, data_pedido, json_completo
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      dadosPedido.yampi_order_id,
      dadosPedido.numero_pedido,
      dadosPedido.status_financeiro,
      dadosPedido.status_entrega,
      dadosPedido.cliente_nome,
      dadosPedido.cliente_email,
      dadosPedido.valor_total,
      dadosPedido.data_pedido,
      dadosPedido.json_completo
    );

    dadosPedido.id = result.lastInsertRowid;
  }

  // Salvar itens do pedido
  if (pedido.items && Array.isArray(pedido.items)) {
    for (const item of pedido.items) {
      await salvarItemPedido(dadosPedido.id || existe.id, item);
    }
  }
}

/**
 * Salvar item de pedido no banco
 * @param {number} pedidoId - ID do pedido local
 * @param {Object} item - Dados do item da Yampi
 */
async function salvarItemPedido(pedidoId, item) {
  // Verificar se já existe
  const existe = db.prepare(`
    SELECT id FROM itens_pedido_yampi 
    WHERE pedido_yampi_id = ? AND yampi_item_id = ?
  `).get(pedidoId, item.id);

  const produto = item.sku_variant?.sku?.product || {};
  const sku = item.sku_variant?.sku || {};

  const dadosItem = {
    pedido_yampi_id: pedidoId,
    yampi_item_id: item.id,
    produto_yampi_nome: produto.name || item.name || '',
    sku: sku.sku || '',
    quantidade: parseInt(item.quantity || 1),
    preco_unitario: parseFloat(item.price?.value || 0),
    valor_total: parseFloat(item.price_total?.value || 0)
  };

  if (existe) {
    // Atualizar
    db.prepare(`
      UPDATE itens_pedido_yampi SET
        produto_yampi_nome = ?,
        sku = ?,
        quantidade = ?,
        preco_unitario = ?,
        valor_total = ?
      WHERE id = ?
    `).run(
      dadosItem.produto_yampi_nome,
      dadosItem.sku,
      dadosItem.quantidade,
      dadosItem.preco_unitario,
      dadosItem.valor_total,
      existe.id
    );
  } else {
    // Inserir
    db.prepare(`
      INSERT INTO itens_pedido_yampi (
        pedido_yampi_id, yampi_item_id, produto_yampi_nome, sku,
        quantidade, preco_unitario, valor_total
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      dadosItem.pedido_yampi_id,
      dadosItem.yampi_item_id,
      dadosItem.produto_yampi_nome,
      dadosItem.sku,
      dadosItem.quantidade,
      dadosItem.preco_unitario,
      dadosItem.valor_total
    );
  }
}

// ============= PRODUTOS =============

/**
 * Buscar produtos da Yampi
 * @param {Object} params - Parâmetros de filtro
 * @returns {Promise<Object>} - Lista de produtos
 */
async function buscarProdutos(params = {}) {
  try {
    const client = getYampiClient();
    const response = await client.get('/catalog/products', { params });
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar produtos Yampi:', error.message);
    throw error;
  }
}

// ============= COLEÇÕES =============

/**
 * Buscar coleções da Yampi
 * @param {Object} params - Parâmetros de filtro
 * @returns {Promise<Object>} - Lista de coleções
 */
async function buscarColecoes(params = {}) {
  try {
    const client = getYampiClient();
    const response = await client.get('/catalog/collections', { params });
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar coleções Yampi:', error.message);
    throw error;
  }
}

// ============= TESTAR CONEXÃO =============

/**
 * Testar conexão com a API Yampi
 * @returns {Promise<Object>} - Resultado do teste
 */
async function testarConexao() {
  try {
    const client = getYampiClient();
    
    // Tentar buscar informações básicas da loja
    const response = await client.get('/catalog/products', { 
      params: { limit: 1 } 
    });

    return {
      sucesso: true,
      mensagem: 'Conexão com Yampi estabelecida com sucesso!',
      dados: {
        alias: getConfig('yampi_alias'),
        produtosEncontrados: response.data.meta?.pagination?.total || 0
      }
    };
  } catch (error) {
    return {
      sucesso: false,
      erro: error.message,
      detalhes: error.response?.data || null
    };
  }
}

module.exports = {
  buscarPedidos,
  buscarPedido,
  sincronizarPedidos,
  buscarProdutos,
  buscarColecoes,
  testarConexao,
  getConfig
};
